from tkinter import *
from UsernameLogin import *
from Face_authentication import *
from login_face import *

def main_go():
    root.destroy()
    main_login()

def face_go():
    root.destroy()
    obj = App()
    #obj

root = Tk()
root.geometry("1225x689+50+30")
try:
    # windows only (remove the minimize/maximize button)
    root.attributes('-toolwindow', True)
except TclError:
    print('Not supported on your platform')

#BackGround Image
img_back = PhotoImage(file= "Images/main_back.png")
ins_img = Label(root, image=img_back).pack()

# _underline = Label(root, text = "____________________",font=("Times New Roman",20), background="white")
# _underline.place(x = 220, y = 430)

# _underline_ = Label(root, text = "________________",font=("Times New Roman",20), background="white")
# _underline_.place(x = 220, y = 545)

userPass = Button(root, text = "Username and Password",font=("Times New Roman",20), border=0, background="white", command= main_go)
userPass.place(x = 220, y = 410)

face = Button(root, text = "Face Authentiation",font=("Times New Roman",20),command=face_go, background="white",  border=0)
face.place(x = 220, y = 522)
root.mainloop()